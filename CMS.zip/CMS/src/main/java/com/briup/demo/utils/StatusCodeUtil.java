package com.briup.demo.utils;
/**
 * 状态码
 * @author 亮澳
 *
 */
public class StatusCodeUtil {
	public static final Integer ERROR_CODE=505;
	public static final Integer NOFOUND_CODE=404;
}
