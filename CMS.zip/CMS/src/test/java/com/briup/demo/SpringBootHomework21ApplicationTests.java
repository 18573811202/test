package com.briup.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHomework21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
